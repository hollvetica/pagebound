import React from 'react';

function Sessions() {
  return (
    <div className="page">
      <h2>Reading Sessions</h2>
      <p>Your active reading sessions</p>
    </div>
  );
}

export default Sessions;