
  # Create Reading App UI

  This is a code bundle for Create Reading App UI. The original project is available at https://www.figma.com/design/TO1zzZNN4guxScjhpLzb4E/Create-Reading-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  